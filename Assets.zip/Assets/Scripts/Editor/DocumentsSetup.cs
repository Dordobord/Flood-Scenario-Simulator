using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class DocumentsSetup
{
    private const string TaskPath = "Assets/Scripts/SO/Tasks/Task_ImportantDocuments.asset";
    private const string MaterialFolder = "Assets/Materials";
    private const string GhostMaterialPath = "Assets/Materials/DocumentsGhost.mat";
    private const string UnlitShaderName = "Universal Render Pipeline/Unlit";

    private const string SpotName = "DocumentsSpot";
    private const string GhostName = "Ghost";
    private const string GhostModelName = "GhostDocuments";
    private const string LabelName = "PlaceLabel";
    private const string PlacedName = "PlacedDocuments";
    private const string HudBarName = "HudHoldPanel";

    private const string PickupPrompt = "Pick up documents";
    private const string LabelText = "Place Documents";

    private const float LabelHeight = 0.25f;
    private const float LabelFontSize = 1.5f;
    private const float HudBarY = 100f;

    private static readonly Color GhostColor = new Color(0.55f, 0.85f, 1f, 0.35f);
    private static readonly Color LabelColor = new Color(0.85f, 0.95f, 1f);
    private static readonly Vector2 LabelSize = new Vector2(2f, 0.5f);

    [MenuItem("Tools/Storm Waits/Set Up Documents Spot")]
    public static void RunSetup()
    {
        GameObject target = Selection.activeGameObject;
        if (target == null || !target.scene.IsValid())
        {
            EditorUtility.DisplayDialog("Documents setup", "Select the cabinet (or the object the documents go on top of) in the Hierarchy first.", "OK");
            return;
        }

        TaskData task = AssetDatabase.LoadAssetAtPath<TaskData>(TaskPath);
        if (task == null)
        {
            EditorUtility.DisplayDialog("Documents setup", "Could not find " + TaskPath + ".", "OK");
            return;
        }

        GameObject documents = FindDocuments(task);
        if (documents == null)
        {
            EditorUtility.DisplayDialog("Documents setup", "Could not find an object in this scene with a Pickup or CarryPickup that uses " + task.name + ".", "OK");
            return;
        }

        if (documents == target || documents.transform.IsChildOf(target.transform))
        {
            EditorUtility.DisplayDialog("Documents setup", "You selected the documents. Select the cabinet instead.", "OK");
            return;
        }

        Bounds targetBounds;
        if (!TryGetBounds(target, out targetBounds))
        {
            EditorUtility.DisplayDialog("Documents setup", target.name + " has no renderer, so the top of it cannot be found.", "OK");
            return;
        }

        Undo.SetCurrentGroupName("Set Up Documents Spot");
        int undoGroup = Undo.GetCurrentGroup();

        List<string> report = new List<string>();
        Material ghostMaterial = GetGhostMaterial(report);
        HoldProgressMinigame holdBar = GetHudHoldBar(report);
        SwapPickup(documents, task, report);

        GameObject oldSpot = GameObject.Find(SpotName);
        if (oldSpot != null)
        {
            Undo.DestroyObjectImmediate(oldSpot);
            report.Add("- Old " + SpotName + ": replaced");
        }

        Vector3 top = new Vector3(targetBounds.center.x, targetBounds.max.y, targetBounds.center.z);
        GameObject spot = BuildSpot(documents, top, ghostMaterial, out GameObject ghost, out GameObject placed);

        PlacementSpot placement = Undo.AddComponent<PlacementSpot>(spot);
        SerializedObject so = new SerializedObject(placement);
        so.FindProperty("task").objectReferenceValue = task;
        so.FindProperty("ghost").objectReferenceValue = ghost;
        so.FindProperty("placedObject").objectReferenceValue = placed;
        so.FindProperty("holdBar").objectReferenceValue = holdBar;
        so.ApplyModifiedPropertiesWithoutUndo();
        report.Add("- " + SpotName + ": placed on top of " + target.name);

        Undo.CollapseUndoOperations(undoGroup);
        EditorSceneManager.MarkSceneDirty(target.scene);
        Selection.activeGameObject = spot;
        AssetDatabase.SaveAssets();

        string text = string.Join("\n", report);
        Debug.Log("Documents setup (" + target.scene.name + "):\n" + text);
        EditorUtility.DisplayDialog("Documents setup finished",
            text + "\n\nSave the scene, then repeat in the other scenario scenes. When every scene is done you can delete Assets/Scripts/Editor/DocumentsSetup.cs. Everything it made stays.", "OK");
    }

    private static GameObject FindDocuments(TaskData task)
    {
        foreach (Pickup pickup in Object.FindObjectsByType<Pickup>(FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            if (new SerializedObject(pickup).FindProperty("task").objectReferenceValue == task) return pickup.gameObject;
        }

        foreach (CarryPickup carry in Object.FindObjectsByType<CarryPickup>(FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            if (new SerializedObject(carry).FindProperty("task").objectReferenceValue == task) return carry.gameObject;
        }
        return null;
    }

    private static bool TryGetBounds(GameObject target, out Bounds bounds)
    {
        bounds = new Bounds();
        bool found = false;

        foreach (Renderer renderer in target.GetComponentsInChildren<Renderer>())
        {
            if (!found)
            {
                bounds = renderer.bounds;
                found = true;
            }
            else
            {
                bounds.Encapsulate(renderer.bounds);
            }
        }
        return found;
    }

    private static Material GetGhostMaterial(List<string> report)
    {
        Material existing = AssetDatabase.LoadAssetAtPath<Material>(GhostMaterialPath);
        if (existing != null)
        {
            report.Add("- Ghost material: already there");
            return existing;
        }

        Shader unlit = Shader.Find(UnlitShaderName);
        if (unlit == null)
        {
            report.Add("- Ghost material: SKIPPED, could not find the URP Unlit shader");
            return null;
        }

        if (!AssetDatabase.IsValidFolder(MaterialFolder)) AssetDatabase.CreateFolder("Assets", "Materials");

        Material material = new Material(unlit);
        material.SetFloat("_Surface", 1f);
        material.SetFloat("_Blend", 0f);
        material.SetFloat("_SrcBlend", (float)UnityEngine.Rendering.BlendMode.SrcAlpha);
        material.SetFloat("_DstBlend", (float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
        material.SetFloat("_ZWrite", 0f);
        material.SetOverrideTag("RenderType", "Transparent");
        material.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
        material.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
        material.SetColor("_BaseColor", GhostColor);

        AssetDatabase.CreateAsset(material, GhostMaterialPath);
        report.Add("- Ghost material: created " + GhostMaterialPath);
        return material;
    }

    private static HoldProgressMinigame GetHudHoldBar(List<string> report)
    {
        HudUI hud = Object.FindAnyObjectByType<HudUI>(FindObjectsInactive.Include);
        if (hud == null)
        {
            report.Add("- HUD hold bar: SKIPPED, no HudCanvas in this scene");
            return null;
        }

        HoldProgressMinigame existing = hud.GetComponentInChildren<HoldProgressMinigame>(true);
        if (existing != null)
        {
            report.Add("- HUD hold bar: already there");
            return existing;
        }

        MinigameManager manager = Object.FindAnyObjectByType<MinigameManager>(FindObjectsInactive.Include);
        HoldProgressMinigame source = null;
        if (manager != null) source = manager.GetComponentInChildren<HoldProgressMinigame>(true);

        if (source == null)
        {
            report.Add("- HUD hold bar: SKIPPED, no MinigameWindow with a HoldPanel in this scene");
            return null;
        }

        GameObject copy = Object.Instantiate(source.gameObject, hud.transform, false);
        copy.name = HudBarName;
        Undo.RegisterCreatedObjectUndo(copy, "Add HUD hold bar");

        RectTransform rect = copy.GetComponent<RectTransform>();
        if (rect != null)
        {
            rect.anchorMin = new Vector2(0.5f, 0f);
            rect.anchorMax = new Vector2(0.5f, 0f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = new Vector2(0f, HudBarY);
        }

        copy.SetActive(false);
        report.Add("- HUD hold bar: copied the HoldPanel into the HudCanvas");
        return copy.GetComponent<HoldProgressMinigame>();
    }

    private static void SwapPickup(GameObject documents, TaskData task, List<string> report)
    {
        Pickup pickup = documents.GetComponent<Pickup>();
        if (pickup == null)
        {
            report.Add("- Documents: already using CarryPickup");
            return;
        }

        Undo.DestroyObjectImmediate(pickup);
        CarryPickup carry = Undo.AddComponent<CarryPickup>(documents);

        SerializedObject so = new SerializedObject(carry);
        so.FindProperty("task").objectReferenceValue = task;
        so.FindProperty("promptOverride").stringValue = PickupPrompt;
        so.ApplyModifiedPropertiesWithoutUndo();
        report.Add("- Documents: swapped Pickup for CarryPickup");
    }

    private static GameObject BuildSpot(GameObject documents, Vector3 top, Material ghostMaterial, out GameObject ghost, out GameObject placed)
    {
        GameObject spot = new GameObject(SpotName);
        Undo.RegisterCreatedObjectUndo(spot, "Create documents spot");
        spot.transform.position = top;

        Bounds docBounds;
        Vector3 offset = Vector3.zero;
        float docHeight = 0f;
        if (TryGetBounds(documents, out docBounds))
        {
            offset = documents.transform.position - docBounds.center;
            offset.y = documents.transform.position.y - docBounds.min.y;
            docHeight = docBounds.size.y;
        }

        ghost = new GameObject(GhostName);
        ghost.transform.SetParent(spot.transform, false);

        GameObject ghostModel = CopyModel(documents, GhostModelName, ghost.transform, top + offset);
        foreach (Renderer renderer in ghostModel.GetComponentsInChildren<Renderer>())
        {
            if (ghostMaterial == null) continue;

            Material[] materials = new Material[renderer.sharedMaterials.Length];
            for (int i = 0; i < materials.Length; i++) materials[i] = ghostMaterial;
            renderer.sharedMaterials = materials;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        }

        if (ghostModel.GetComponentInChildren<Collider>() == null) ghostModel.AddComponent<BoxCollider>();
        foreach (Collider collider in ghostModel.GetComponentsInChildren<Collider>()) collider.isTrigger = false;

        BuildLabel(ghost.transform, top + Vector3.up * (docHeight + LabelHeight));

        placed = CopyModel(documents, PlacedName, spot.transform, top + offset);
        placed.SetActive(false);

        return spot;
    }

    private static GameObject CopyModel(GameObject documents, string name, Transform parent, Vector3 position)
    {
        GameObject copy = Object.Instantiate(documents, parent);
        copy.name = name;
        copy.SetActive(true);
        copy.transform.position = position;
        copy.transform.rotation = documents.transform.rotation;
        copy.transform.localScale = documents.transform.lossyScale;

        foreach (MonoBehaviour behaviour in copy.GetComponentsInChildren<MonoBehaviour>(true))
        {
            Object.DestroyImmediate(behaviour);
        }
        return copy;
    }

    private static void BuildLabel(Transform parent, Vector3 position)
    {
        GameObject label = new GameObject(LabelName);
        label.transform.SetParent(parent, false);
        label.transform.position = position;

        TextMeshPro text = label.AddComponent<TextMeshPro>();
        text.text = LabelText;
        text.fontSize = LabelFontSize;
        text.color = LabelColor;
        text.alignment = TextAlignmentOptions.Center;
        text.rectTransform.sizeDelta = LabelSize;

        label.AddComponent<FaceCamera>();
    }
}
