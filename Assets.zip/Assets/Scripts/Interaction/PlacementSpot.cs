using UnityEngine;

public class PlacementSpot : MonoBehaviour, IHoldInteractable
{
    [Header("Task")]
    [SerializeField] private TaskData task;

    [Header("Objects")]
    [SerializeField] private GameObject ghost;
    [SerializeField] private GameObject placedObject;

    [Header("Hold Bar")]
    [SerializeField] private HoldProgressMinigame holdBar;

    private bool holding;
    private bool placed;
    private float holdStartTime;

    public bool CanHold
    {
        get { return !placed && holdBar != null && IsCarrying(); }
    }

    private void Awake()
    {
        if (task == null || task.rewardItem == null)
        {
            Debug.LogWarning("PlacementSpot: assign a Task that has a Reward Item.");
        }

        if (holdBar == null)
        {
            Debug.LogWarning("PlacementSpot: Hold Bar is not assigned. Drag the HoldPanel from the HudCanvas into it.");
        }
        else
        {
            holdBar.Finished += OnHoldFinished;
            holdBar.End();
        }

        if (ghost != null) ghost.SetActive(false);
        if (placedObject != null) placedObject.SetActive(false);
    }

    private void OnDestroy()
    {
        if (holdBar != null) holdBar.Finished -= OnHoldFinished;
    }

    private void Update()
    {
        if (ghost == null) return;

        bool showGhost = !placed && IsCarrying();
        if (ghost.activeSelf != showGhost) ghost.SetActive(showGhost);
    }

    private bool IsCarrying()
    {
        if (task == null || task.rewardItem == null) return false;
        if (TaskManager.Instance != null && TaskManager.Instance.IsCompleted(task)) return false;
        return InventoryManager.Instance != null && InventoryManager.Instance.Contains(task.rewardItem);
    }

    public void HoldTick()
    {
        if (!CanHold) return;

        if (!holding)
        {
            holding = true;
            holdStartTime = Time.time;
            holdBar.Begin(task.minigame);
        }

        holdBar.Tick();
    }

    public void HoldCancel()
    {
        if (!holding) return;

        holding = false;
        holdBar.End();
    }

    private void OnHoldFinished(bool success)
    {
        if (!holding || !success) return;

        holding = false;
        holdBar.End();
        Place(Time.time - holdStartTime);
    }

    private void Place(float seconds)
    {
        placed = true;

        if (InventoryManager.Instance != null) InventoryManager.Instance.Remove(task.rewardItem);
        if (ghost != null) ghost.SetActive(false);
        if (placedObject != null) placedObject.SetActive(true);

        if (TaskManager.Instance != null) TaskManager.Instance.RecordAttempt(task, true, seconds);
        GameEvents.RaiseMessage(GameSettings.Current.taskCompleteMessage + task.title);
    }
}
