using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class RainSetup
{
    private const string SceneFolder = "Assets/Scenes";
    private const string RainShaderPath = "Assets/Shaders/RainStreak.shadergraph";
    private const string WetShaderPath = "Assets/Shaders/WetGround.shadergraph";
    private const string RainMaterialPath = "Assets/Materials/Rain.mat";
    private const string WeatherPrefabPath = "Assets/Prefabs/Weather.prefab";
    private const string BlockoutFolder = "Assets/Materials/Blockout";

    private static readonly string[] WetMaterialNames = { "Blockout_Ground", "Blockout_Road", "Blockout_Sidewalk" };

    [MenuItem("Tools/Storm Waits/Set Up Rain")]
    public static void RunSetup()
    {
        Shader rainShader = AssetDatabase.LoadAssetAtPath<Shader>(RainShaderPath);
        Shader wetShader = AssetDatabase.LoadAssetAtPath<Shader>(WetShaderPath);
        if (rainShader == null || wetShader == null)
        {
            EditorUtility.DisplayDialog("Rain setup", "Could not find the Shader Graphs in Assets/Shaders. Copy them in first.", "OK");
            return;
        }

        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        string report = "";
        report += CreateRainMaterial(rainShader) + "\n";
        report += CreateWeatherPrefab() + "\n";
        report += ConvertGroundMaterials(wetShader) + "\n";

        List<string> scenePaths = SetScenarioValues(ref report);
        foreach (string path in scenePaths)
        {
            report += AddWeatherToScene(path) + "\n";
        }

        AssetDatabase.SaveAssets();
        Debug.Log("Rain setup:\n" + report);
        EditorUtility.DisplayDialog("Rain setup finished",
            report + "\nYou can now delete Assets/Scripts/Editor/RainSetup.cs. Everything it made stays.", "OK");
    }

    private static string CreateRainMaterial(Shader rainShader)
    {
        if (AssetDatabase.LoadAssetAtPath<Material>(RainMaterialPath) != null) return "- Rain material: already there";

        if (!AssetDatabase.IsValidFolder("Assets/Materials")) AssetDatabase.CreateFolder("Assets", "Materials");
        Material material = new Material(rainShader);
        material.name = "Rain";
        AssetDatabase.CreateAsset(material, RainMaterialPath);
        return "- Rain material: created " + RainMaterialPath;
    }

    private static string CreateWeatherPrefab()
    {
        if (AssetDatabase.LoadAssetAtPath<GameObject>(WeatherPrefabPath) != null) return "- Weather prefab: already there";

        GameObject root = new GameObject("Weather", typeof(RainController), typeof(AudioSource));
        AudioSource audio = root.GetComponent<AudioSource>();
        audio.loop = true;
        audio.playOnAwake = false;
        audio.spatialBlend = 0f;
        audio.volume = 0f;

        GameObject rainObject = new GameObject("Rain", typeof(ParticleSystem));
        rainObject.transform.SetParent(root.transform, false);
        rainObject.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
        ParticleSystem rain = rainObject.GetComponent<ParticleSystem>();
        SetUpParticles(rain);

        SerializedObject so = new SerializedObject(root.GetComponent<RainController>());
        so.FindProperty("rain").objectReferenceValue = rain;
        so.FindProperty("rainSound").objectReferenceValue = audio;
        so.ApplyModifiedPropertiesWithoutUndo();

        PrefabUtility.SaveAsPrefabAsset(root, WeatherPrefabPath);
        Object.DestroyImmediate(root);
        return "- Weather prefab: created " + WeatherPrefabPath;
    }

    private static void SetUpParticles(ParticleSystem rain)
    {
        ParticleSystem.MainModule main = rain.main;
        main.loop = true;
        main.playOnAwake = true;
        main.startLifetime = 1.2f;
        main.startSpeed = 20f;
        main.startSize = 0.05f;
        main.startColor = new Color(1f, 1f, 1f, 0.6f);
        main.gravityModifier = 0f;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.maxParticles = 8000;

        ParticleSystem.EmissionModule emission = rain.emission;
        emission.rateOverTime = 0f;

        ParticleSystem.ShapeModule shape = rain.shape;
        shape.shapeType = ParticleSystemShapeType.Box;
        shape.scale = new Vector3(40f, 40f, 0f);

        ParticleSystem.CollisionModule collision = rain.collision;
        collision.enabled = true;
        collision.type = ParticleSystemCollisionType.World;
        collision.mode = ParticleSystemCollisionMode.Collision3D;
        collision.lifetimeLoss = 1f;
        collision.bounce = 0f;
        collision.quality = ParticleSystemCollisionQuality.Medium;

        ParticleSystemRenderer renderer = rain.GetComponent<ParticleSystemRenderer>();
        renderer.renderMode = ParticleSystemRenderMode.Stretch;
        renderer.lengthScale = 2f;
        renderer.velocityScale = 0.025f;
        renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        renderer.receiveShadows = false;
        renderer.sharedMaterial = AssetDatabase.LoadAssetAtPath<Material>(RainMaterialPath);
    }

    private static string ConvertGroundMaterials(Shader wetShader)
    {
        List<string> converted = new List<string>();
        List<string> missing = new List<string>();

        foreach (string name in WetMaterialNames)
        {
            Material material = AssetDatabase.LoadAssetAtPath<Material>(BlockoutFolder + "/" + name + ".mat");
            if (material == null)
            {
                missing.Add(name);
                continue;
            }
            if (material.shader == wetShader) continue;

            Color color = material.HasProperty("_BaseColor") ? material.GetColor("_BaseColor") : material.color;
            material.shader = wetShader;
            material.SetColor("_BaseColor", color);
            EditorUtility.SetDirty(material);
            converted.Add(name);
        }

        string result = "- Wet ground: " + (converted.Count > 0 ? "switched " + string.Join(", ", converted) + " to WetGround" : "materials already wet");
        if (missing.Count > 0) result += ", could not find " + string.Join(", ", missing);
        return result;
    }

    private static List<string> SetScenarioValues(ref string report)
    {
        List<string> scenePaths = new List<string>();
        List<string> names = new List<string>();

        foreach (string guid in AssetDatabase.FindAssets("t:ScenarioData"))
        {
            ScenarioData scenario = AssetDatabase.LoadAssetAtPath<ScenarioData>(AssetDatabase.GUIDToAssetPath(guid));
            if (scenario == null || string.IsNullOrEmpty(scenario.sceneName)) continue;

            switch (scenario.type)
            {
                case ScenarioType.Urban:
                    SetRain(scenario, 0.5f, 0.8f);
                    break;
                case ScenarioType.FlashFlood:
                    SetRain(scenario, 0.7f, 1f);
                    break;
                case ScenarioType.River:
                    SetRain(scenario, 0.5f, 0.8f);
                    break;
                case ScenarioType.Coastal:
                    SetRain(scenario, 0.6f, 0.9f);
                    break;
            }
            names.Add(scenario.displayName);

            string path = SceneFolder + "/" + scenario.sceneName + ".unity";
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) != null && !scenePaths.Contains(path)) scenePaths.Add(path);
        }

        report += "- Scenario rain strengths set for " + string.Join(", ", names) + "\n";
        return scenePaths;
    }

    private static void SetRain(ScenarioData scenario, float prep, float evacuation)
    {
        scenario.prepRainStrength = prep;
        scenario.evacuationRainStrength = evacuation;
        EditorUtility.SetDirty(scenario);
    }

    private static string AddWeatherToScene(string path)
    {
        Scene scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
        if (Object.FindAnyObjectByType<RainController>(FindObjectsInactive.Include) != null)
        {
            return "- " + scene.name + ": Weather already there";
        }

        GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(WeatherPrefabPath);
        GameObject weather = (GameObject)PrefabUtility.InstantiatePrefab(prefab);

        string result = "- " + scene.name + ": added Weather";
        Light sun = FindSun();
        if (sun != null)
        {
            SerializedObject so = new SerializedObject(weather.GetComponent<RainController>());
            so.FindProperty("sun").objectReferenceValue = sun;
            so.ApplyModifiedPropertiesWithoutUndo();
            result += ", sun set to " + sun.name;
        }
        else
        {
            result += ", no directional light found so the sun will not dim";
        }

        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene);
        return result;
    }

    private static Light FindSun()
    {
        if (RenderSettings.sun != null) return RenderSettings.sun;

        foreach (Light light in Object.FindObjectsByType<Light>(FindObjectsSortMode.None))
        {
            if (light.type == LightType.Directional) return light;
        }
        return null;
    }
}
