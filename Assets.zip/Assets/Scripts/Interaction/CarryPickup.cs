using UnityEngine;

public class CarryPickup : MonoBehaviour, IInteractable
{
    [Header("Task")]
    [SerializeField] private TaskData task;
    [SerializeField] private string promptOverride;

    public string Prompt
    {
        get
        {
            if (!string.IsNullOrEmpty(promptOverride)) return promptOverride;
            if (task != null) return task.title;
            return GameSettings.Current.defaultPrompt;
        }
    }

    public bool CanInteract
    {
        get
        {
            if (task == null || task.rewardItem == null) return false;
            if (TaskManager.Instance != null && TaskManager.Instance.IsCompleted(task)) return false;
            if (InventoryManager.Instance == null) return false;
            return !InventoryManager.Instance.Contains(task.rewardItem);
        }
    }

    private void Awake()
    {
        if (task != null && task.rewardItem == null)
        {
            Debug.LogWarning("CarryPickup: the task '" + task.title + "' has no Reward Item, so there is nothing to carry.");
        }
    }

    public void Interact()
    {
        if (!CanInteract) return;

        GameSettings settings = GameSettings.Current;
        InventoryManager inventory = InventoryManager.Instance;

        if (!inventory.TryAdd(task.rewardItem))
        {
            GameEvents.RaiseMessage(settings.inventoryFullMessage);
            return;
        }

        GameEvents.RaiseMessage(settings.collectedMessage + task.rewardItem.displayName);
        gameObject.SetActive(false);
    }
}
