using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class CloudSetup
{
    private const string SceneFolder = "Assets/Scenes";
    private const string CloudShaderPath = "Assets/Shaders/CloudLayer.shadergraph";
    private const string CloudMaterialPath = "Assets/Materials/Clouds.mat";
    private const string WeatherPrefabPath = "Assets/Prefabs/Weather.prefab";
    private const string CloudsName = "Clouds";
    private const string EnvironmentName = "Environment";
    private const string HouseName = "UrbanHouse";
    private const string ExtrasName = "HouseExtras";
    private const string RoofName = "RainRoof";

    private const float CloudHeightAboveWeather = 28f;
    private const float CloudPlaneScale = 120f;
    private const float RoofOverhang = 0.3f;
    private const float RoofThickness = 1f;

    [MenuItem("Tools/Storm Waits/Set Up Clouds")]
    public static void RunSetup()
    {
        Shader cloudShader = AssetDatabase.LoadAssetAtPath<Shader>(CloudShaderPath);
        if (cloudShader == null)
        {
            EditorUtility.DisplayDialog("Cloud setup", "Could not find " + CloudShaderPath + ". Copy it in first.", "OK");
            return;
        }

        if (AssetDatabase.LoadAssetAtPath<GameObject>(WeatherPrefabPath) == null)
        {
            EditorUtility.DisplayDialog("Cloud setup", "Could not find " + WeatherPrefabPath + ". Run Set Up Rain first.", "OK");
            return;
        }

        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        string report = "";
        report += CreateCloudMaterial(cloudShader) + "\n";
        report += AddCloudsToWeather() + "\n";

        foreach (string path in FindScenarioScenes())
        {
            report += AddRainRoof(path) + "\n";
        }

        AssetDatabase.SaveAssets();
        Debug.Log("Cloud setup:\n" + report);
        EditorUtility.DisplayDialog("Cloud setup finished",
            report + "\nYou can now delete Assets/Scripts/Editor/CloudSetup.cs. Everything it made stays.", "OK");
    }

    private static string CreateCloudMaterial(Shader cloudShader)
    {
        if (AssetDatabase.LoadAssetAtPath<Material>(CloudMaterialPath) != null) return "- Cloud material: already there";

        if (!AssetDatabase.IsValidFolder("Assets/Materials")) AssetDatabase.CreateFolder("Assets", "Materials");
        Material material = new Material(cloudShader);
        material.name = CloudsName;
        AssetDatabase.CreateAsset(material, CloudMaterialPath);
        return "- Cloud material: created " + CloudMaterialPath;
    }

    private static string AddCloudsToWeather()
    {
        GameObject root = PrefabUtility.LoadPrefabContents(WeatherPrefabPath);
        string result;

        if (root.transform.Find(CloudsName) != null)
        {
            result = "- Weather prefab: clouds already there";
        }
        else
        {
            GameObject clouds = GameObject.CreatePrimitive(PrimitiveType.Plane);
            clouds.name = CloudsName;
            Object.DestroyImmediate(clouds.GetComponent<Collider>());
            clouds.transform.SetParent(root.transform, false);
            clouds.transform.localPosition = new Vector3(0f, CloudHeightAboveWeather, 0f);
            clouds.transform.localScale = new Vector3(CloudPlaneScale, 1f, CloudPlaneScale);

            MeshRenderer renderer = clouds.GetComponent<MeshRenderer>();
            renderer.sharedMaterial = AssetDatabase.LoadAssetAtPath<Material>(CloudMaterialPath);
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            renderer.receiveShadows = false;

            result = "- Weather prefab: added a cloud layer about 40 m above the player";
        }

        PrefabUtility.SaveAsPrefabAsset(root, WeatherPrefabPath);
        PrefabUtility.UnloadPrefabContents(root);
        return result;
    }

    private static List<string> FindScenarioScenes()
    {
        List<string> paths = new List<string>();
        foreach (string guid in AssetDatabase.FindAssets("t:ScenarioData"))
        {
            ScenarioData scenario = AssetDatabase.LoadAssetAtPath<ScenarioData>(AssetDatabase.GUIDToAssetPath(guid));
            if (scenario == null || string.IsNullOrEmpty(scenario.sceneName)) continue;

            string path = SceneFolder + "/" + scenario.sceneName + ".unity";
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) != null && !paths.Contains(path)) paths.Add(path);
        }
        return paths;
    }

    private static string AddRainRoof(string path)
    {
        Scene scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Single);

        Transform environment = null;
        foreach (GameObject rootObject in scene.GetRootGameObjects())
        {
            if (rootObject.name == EnvironmentName) environment = rootObject.transform;
        }

        Transform house = environment != null ? environment.Find(HouseName) : null;
        Transform extras = environment != null ? environment.Find(ExtrasName) : null;
        if (house == null || extras == null) return "- " + scene.name + ": rain roof SKIPPED (no " + HouseName + " or " + ExtrasName + ")";
        if (extras.Find(RoofName) != null) return "- " + scene.name + ": rain roof already there";

        Bounds bounds = GetBounds(house.gameObject);
        GameObject roof = new GameObject(RoofName);
        roof.transform.SetParent(extras, true);
        roof.transform.position = new Vector3(bounds.center.x, bounds.max.y + RoofThickness * 0.5f, bounds.center.z);

        BoxCollider box = roof.AddComponent<BoxCollider>();
        box.size = new Vector3(bounds.size.x + RoofOverhang * 2f, RoofThickness, bounds.size.z + RoofOverhang * 2f);

        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene);
        return "- " + scene.name + ": added an invisible roof so rain stops above the house";
    }

    private static Bounds GetBounds(GameObject target)
    {
        Bounds bounds = new Bounds(target.transform.position, Vector3.zero);
        bool first = true;

        foreach (Renderer renderer in target.GetComponentsInChildren<Renderer>(true))
        {
            if (renderer.bounds.size == Vector3.zero) continue;
            if (first)
            {
                bounds = renderer.bounds;
                first = false;
            }
            else
            {
                bounds.Encapsulate(renderer.bounds);
            }
        }
        return bounds;
    }
}
