using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class ShelterSetup
{
    private const string SceneFolder = "Assets/Scenes";
    private const string FloorMaterialPath = "Assets/Materials/Blockout/Blockout_HouseFloor.mat";
    private const string LitShaderName = "Universal Render Pipeline/Lit";
    private const string EnvironmentName = "Environment";
    private const string HouseName = "UrbanHouse";
    private const string ExtrasName = "HouseExtras";
    private const string ShelterName = "RainShelter";
    private const string FloorName = "HouseFloor";

    private const float ShelterExtraHeight = 1.2f;
    private const float FloorInset = 0.05f;
    private const float FloorThickness = 0.02f;

    private static readonly string[] FloorReferenceNames = { "Lower Stairs", "Stair_1" };
    private static readonly Color FloorColor = new Color(0.72f, 0.7f, 0.66f);

    [MenuItem("Tools/Storm Waits/Set Up Rain Shelter")]
    public static void RunSetup()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        string report = CreateFloorMaterial() + "\n";
        foreach (string path in FindScenarioScenes())
        {
            report += SetUpScene(path) + "\n";
        }

        AssetDatabase.SaveAssets();
        Debug.Log("Rain shelter setup:\n" + report);
        EditorUtility.DisplayDialog("Rain shelter setup finished",
            report + "\nYou can now delete Assets/Scripts/Editor/ShelterSetup.cs. Everything it made stays.", "OK");
    }

    private static string CreateFloorMaterial()
    {
        if (AssetDatabase.LoadAssetAtPath<Material>(FloorMaterialPath) != null) return "- House floor material: already there";

        Shader lit = Shader.Find(LitShaderName);
        if (lit == null) return "- House floor material: SKIPPED, could not find the URP Lit shader";

        if (!AssetDatabase.IsValidFolder("Assets/Materials")) AssetDatabase.CreateFolder("Assets", "Materials");
        if (!AssetDatabase.IsValidFolder("Assets/Materials/Blockout")) AssetDatabase.CreateFolder("Assets/Materials", "Blockout");

        Material material = new Material(lit);
        material.SetColor("_BaseColor", FloorColor);
        AssetDatabase.CreateAsset(material, FloorMaterialPath);
        return "- House floor material: created " + FloorMaterialPath;
    }

    private static List<string> FindScenarioScenes()
    {
        List<string> paths = new List<string>();
        foreach (string guid in AssetDatabase.FindAssets("t:ScenarioData"))
        {
            ScenarioData scenario = AssetDatabase.LoadAssetAtPath<ScenarioData>(AssetDatabase.GUIDToAssetPath(guid));
            if (scenario == null || string.IsNullOrEmpty(scenario.sceneName)) continue;

            string path = SceneFolder + "/" + scenario.sceneName + ".unity";
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) != null && !paths.Contains(path)) paths.Add(path);
        }
        return paths;
    }

    private static string SetUpScene(string path)
    {
        Scene scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Single);

        Transform environment = null;
        foreach (GameObject rootObject in scene.GetRootGameObjects())
        {
            if (rootObject.name == EnvironmentName) environment = rootObject.transform;
        }

        Transform house = environment != null ? environment.Find(HouseName) : null;
        Transform extras = environment != null ? environment.Find(ExtrasName) : null;
        if (house == null || extras == null) return "- " + scene.name + ": SKIPPED (no " + HouseName + " or " + ExtrasName + ")";

        Bounds bounds = GetBounds(house.gameObject);
        List<string> done = new List<string>();

        if (extras.Find(ShelterName) == null)
        {
            AddShelter(extras, bounds);
            done.Add("rain shelter");
        }

        if (extras.Find(FloorName) == null)
        {
            AddFloor(extras, bounds, FindFloorLevel(house, bounds));
            done.Add("dry floor");
        }

        if (done.Count == 0) return "- " + scene.name + ": already set up";

        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene);
        return "- " + scene.name + ": added " + string.Join(" and ", done);
    }

    private static void AddShelter(Transform extras, Bounds bounds)
    {
        GameObject shelter = new GameObject(ShelterName);
        shelter.transform.SetParent(extras, true);

        float height = bounds.size.y + ShelterExtraHeight;
        shelter.transform.position = new Vector3(bounds.center.x, bounds.min.y + height * 0.5f, bounds.center.z);

        BoxCollider box = shelter.AddComponent<BoxCollider>();
        box.isTrigger = true;
        box.size = new Vector3(bounds.size.x, height, bounds.size.z);

        shelter.AddComponent<RainShelter>();
    }

    private static void AddFloor(Transform extras, Bounds bounds, float floorY)
    {
        GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
        floor.name = FloorName;
        Object.DestroyImmediate(floor.GetComponent<Collider>());
        floor.transform.SetParent(extras, true);
        floor.transform.position = new Vector3(bounds.center.x, floorY + FloorThickness * 0.5f, bounds.center.z);
        floor.transform.localScale = new Vector3(bounds.size.x - FloorInset * 2f, FloorThickness, bounds.size.z - FloorInset * 2f);

        Material material = AssetDatabase.LoadAssetAtPath<Material>(FloorMaterialPath);
        if (material != null) floor.GetComponent<MeshRenderer>().sharedMaterial = material;
        floor.isStatic = true;
    }

    private static float FindFloorLevel(Transform house, Bounds houseBounds)
    {
        foreach (string name in FloorReferenceNames)
        {
            foreach (Transform child in house.GetComponentsInChildren<Transform>(true))
            {
                if (child.name == name) return GetBounds(child.gameObject).min.y;
            }
        }
        return house.position.y;
    }

    private static Bounds GetBounds(GameObject target)
    {
        Bounds bounds = new Bounds(target.transform.position, Vector3.zero);
        bool first = true;

        foreach (Renderer renderer in target.GetComponentsInChildren<Renderer>(true))
        {
            if (renderer.bounds.size == Vector3.zero) continue;
            if (first)
            {
                bounds = renderer.bounds;
                first = false;
            }
            else
            {
                bounds.Encapsulate(renderer.bounds);
            }
        }
        return bounds;
    }
}
